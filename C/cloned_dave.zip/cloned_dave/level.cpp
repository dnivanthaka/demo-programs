#include "levels.h"

void
load_map( char *file, void *buffer )
{
    buffer = malloc( sizeof(char) * 65 * 10 );
}

void
