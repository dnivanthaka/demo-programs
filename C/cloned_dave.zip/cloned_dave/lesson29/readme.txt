Copyright Notice:
-----------------
The files within this zip file are copyrighted by Lazy Foo' Productions (2004-2012)
and may not be redestributed without written permission.

This project is linked against:
----------------------------------------
Windows:
SDL
SDLmain
SDL_image

*nix:
SDL
SDL_image