#ifndef __G__RAND__
#define __G__RAND__

static void init_rand();
static unsigned int getrand();

#endif
