

#include"Arrow.h"

Arrow::Arrow()
{
    used = false;
}
